
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.modproject.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.modproject.item.IlluminiteIngotsItem;
import net.mcreator.modproject.item.IlluminiteFragmentItem;
import net.mcreator.modproject.item.IlluminiteDustItem;
import net.mcreator.modproject.ModProjectMod;

public class ModProjectModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ModProjectMod.MODID);
	public static final RegistryObject<Item> MYSTERIOUS_DIRT = block(ModProjectModBlocks.MYSTERIOUS_DIRT, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MYSTERIOUSGRASS = block(ModProjectModBlocks.MYSTERIOUSGRASS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAGIC_WOOD = block(ModProjectModBlocks.MAGIC_WOOD, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> MAGIC_LEAVES = block(ModProjectModBlocks.MAGIC_LEAVES, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ILLUMINITE_DUST = REGISTRY.register("illuminite_dust", () -> new IlluminiteDustItem());
	public static final RegistryObject<Item> ILLUMINITE_ORE = block(ModProjectModBlocks.ILLUMINITE_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ILLUMINITE_BLOCK = block(ModProjectModBlocks.ILLUMINITE_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ILLUMINITE_INGOTS = REGISTRY.register("illuminite_ingots", () -> new IlluminiteIngotsItem());
	public static final RegistryObject<Item> ILLUMINITE_FRAGMENT = REGISTRY.register("illuminite_fragment", () -> new IlluminiteFragmentItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
