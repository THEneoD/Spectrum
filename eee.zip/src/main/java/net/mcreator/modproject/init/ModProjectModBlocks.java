
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.modproject.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.ColorHandlerEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.modproject.block.MysteriousgrassBlock;
import net.mcreator.modproject.block.MysteriousDirtBlock;
import net.mcreator.modproject.block.MagicWoodBlock;
import net.mcreator.modproject.block.MagicLeavesBlock;
import net.mcreator.modproject.block.IlluminiteOreBlock;
import net.mcreator.modproject.block.IlluminiteBlockBlock;
import net.mcreator.modproject.ModProjectMod;

public class ModProjectModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ModProjectMod.MODID);
	public static final RegistryObject<Block> MYSTERIOUS_DIRT = REGISTRY.register("mysterious_dirt", () -> new MysteriousDirtBlock());
	public static final RegistryObject<Block> MYSTERIOUSGRASS = REGISTRY.register("mysteriousgrass", () -> new MysteriousgrassBlock());
	public static final RegistryObject<Block> MAGIC_WOOD = REGISTRY.register("magic_wood", () -> new MagicWoodBlock());
	public static final RegistryObject<Block> MAGIC_LEAVES = REGISTRY.register("magic_leaves", () -> new MagicLeavesBlock());
	public static final RegistryObject<Block> ILLUMINITE_ORE = REGISTRY.register("illuminite_ore", () -> new IlluminiteOreBlock());
	public static final RegistryObject<Block> ILLUMINITE_BLOCK = REGISTRY.register("illuminite_block", () -> new IlluminiteBlockBlock());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
		}

		@SubscribeEvent
		public static void blockColorLoad(ColorHandlerEvent.Block event) {
			MysteriousgrassBlock.blockColorLoad(event);
		}
	}
}
